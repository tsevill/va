var selectedYear;
var selectedType;
var items;
var countries;
var rawData;
var rawJSON;
var filteredData;
var numberofBins = 9;
var pages = [ 15, 50, 100 ];
var pageSize = 24;
var selectedPage = 0;
var linkSizeThresholds = [ 1, 5, 20, 50 ];
var selectedLinkSizeThreshold = 1;
var percents = [ 0, 1 ];
var minYear = 2013;
var maxYear = 2013;
var itemCodes;
var FAOtoPOP;
var POPtoFAO;
var ISO3toCC;
var siFormat = d3.format('.3s');
var layersToCascade = 1;
var simulate = false;

var numberOfPages = function() {
	if (rawData) {
		return Math.ceil(filteredData.length / pageSize);
	} else {
		return 1;
	}
}
var selectedItem;

var updateHistograms = function() {
	var data = []
			.concat(rawData.filter(function(d) {
				if (!selectedItem)
					return true;
				return +d.key == +selectedItem;
			}), [])
			.map(
					function(d) {
						var newD = {
							key : d.key,
							values : [].concat(d.values),
						}
						var count = d.values.length;
						newD.values = newD.values
								.filter(function(d, i) {
									if (!countries[d.ExportingCountryCode]
											|| !countries[d.ImportingCountryCode]) {
										return false;
									}
									return (+(d.TradeLinksValue / countries[d.ExportingCountryCode].TotalExportValue) >= percents[0])
											&& (+(d.TradeLinksValue / countries[d.ExportingCountryCode].TotalExportValue) <= percents[1]);
								})
						return newD;
					}, [])
	getTriadDistribution(data);
	drawAllHistograms(data);
}
var normalDistribution;
var init = true;
var getTriadDistribution = function(data) {
	d3.range(1, 14, 1).forEach(function(d) {
		d3.select("#triad_" + d).selectAll('.textPercentage').remove()
	})

	var triadsRequest = data.filter(function(d) {
		return d.values.length > 0 && d.key == selectedItem;
	})
	if (triadsRequest.length == 0)
		return;
	triadsRequest = triadsRequest.map(function(d) {
		var countries = graph.nodes ? graph.nodes.map(function(d) {
			return d["Country Code"];
		}) : d.values.map(function(d) {
			return d.ExportingCountryCode;
		})
		return {
			item : d.key,
			countries : Array.from(new Set(countries))
		}
	})
	var count = triadsRequest.length;
	var processed = 0;
	var triads = [];
	var distributionChartMargin = {
		bottom : 50,
		left : 50,
		top : 50,
		right : 50
	}, width = 600 - distributionChartMargin.left
			- distributionChartMargin.right, height = 400
			- distributionChartMargin.bottom - distributionChartMargin.top;
	var svg, g;

	var x = d3.scaleLinear().domain([ 1, 13 ]).rangeRound([ 0, width ]);

	var y = d3.scaleLinear().domain([ 0, 1 ]).rangeRound([ height, 0 ]);

	if (init) {
		svg = d3.select("#triadDistributionChartDiv").append('svg').attr('id',
				'distributionChart').attr('height', 400).attr('width', 600);
		g = svg.append("g").attr('id', 'distributionChartGroup').attr(
				"transform",
				"translate(" + distributionChartMargin.left + ","
						+ distributionChartMargin.top + ")");
		g.append('text').text('Normal Distribution Profile').style('font-size',
				'2em').attr('x', 20).attr('y', 350).style('text-anchor',
				'center').style('stroke', 'steelblue')
		g.append('text').text('Filtered Selection').style('font-size', '2em')
				.attr('x', 300).attr('y', 350).style('text-anchor', 'center')
				.style('stroke', 'green')

		g.append("g").attr("class", "axis axis--x").attr("transform",
				"translate(0," + height + ")").call(d3.axisBottom().scale(x));

		g.append("g").attr("class", "axis axis--y")
				.call(d3.axisLeft().scale(y));
	} else {
		svg = d3.select('#distributionChart');
		g = d3.select('#distributionChartGroup');
	}

	var line = d3.line().x(function(d) {
		return x(+(d.key));
	}).y(function(d) {
		return y(d.value / d.totalTriads);
	});

	var drawTriads = function(data) {
		d3.select('#distributionPath').datum(data).attr("class", "line")
				.transition().attr("d", function(d) {
					return line(d);
				});

		d3.range(1, 14, 1).forEach(
				function(index) {
					d3.select("#triad_" + index).selectAll('textPercentage')
							.text("0.00 %")
					if (data.filter(function(d) {
						return +(d.key) == d;
					}, []).length == 0) {
						d3.select("#triad_" + index).transition()
								.duration(2000).style('background-color',
										'white')
					}
				})

		var color = d3.scaleLinear().domain([ 0, d3.max(data.map(function(d) {
			return d.value / d.totalTriads;
		})) ]).interpolate(d3.interpolateRgb).range([ "#ffffff", "#33ff33" ])

		data.forEach(function(d) {
			d3.select("#triad_" + d.key).selectAll('.textPercentage').remove()
			d3.select("#triad_" + d.key).transition().duration(2000).style(
					'background-color', color(d.value / d.totalTriads))
			d3.select("#triad_" + d.key).select('g').append('text').classed(
					'textPercentage', true).attr('y', "80px").style(
					'text-anchor', 'center').style('font-size', '1.5em').text(
					((d.value / d.totalTriads) * 100).toFixed(2) + " %")
		})
	}

	g.append("path").attr('id', 'distributionPath').attr("class", "line");

	if (init || percents[0] != 0 || percents[1] != 1 || selectedItem) {
		triadsRequest
				.forEach(function(d) {
					$
							.ajax({
								url : service_url + 'dbtriaddistribution?'
										+ 'itemCode=' + d.item + '&'
										+ 'countries=' + d.countries + '&'
										+ 'callback=?',
								dataType : 'jsonp',
								success : function(json) {
									json = json.filter(function(d) {
										return d;
									}, [])
									triads.push({
										item : d.item,
										triads : json.map(function(d) {
											d.count = +(d.count);
											return d;
										}),
										totalTriads : json.map(function(d) {
											return +(d.count);
										}).reduce(function(acc, curr) {
											return acc += curr;
										}, 0),
									});
									d3
											.select("#itemHeader_" + d.item)
											.datum(triads[triads.length - 1])
											.on(
													'mouseover',
													function(d) {
														var html = "<h3>Triads:</h3>";
														d.triads
																.forEach(function(
																		triad) {
																	html += "<h4>Type "
																			+ triad.type
																			+ ": "
																			+ triad.count
																			+ " ("
																			+ ((triad.count / d.totalTriads) * 100)
																					.toFixed(2)
																			+ "%)</h4>";
																})
														tooltip.style(
																'visibility',
																'visible')
																.html(html)
													}).on(
													'mouseout',
													function(d) {
														tooltip.style(
																'visibility',
																'hidden')
													}).on('mousemove',
													ttPosition)
									processed++;
									allDone();
									d3
											.select("#triadDistributionLoading")
											.attr('width',
													70 * 13 * processed / count)
								}
							});
				});
	} else {
		drawTriads(normalDistribution);
	}

	init = false;

	var allDone = function() {
		var flattened = triads.reduce(function(acc, curr) {
			return acc.concat(curr.triads);
		}, []);

		var nested = d3.nest().key(function(d) {
			return d.type;
		}).rollup(function(d) {
			return d.map(function(d) {
				return d.count;
			}).reduce(function(acc, curr) {
				return acc += curr;
			}, 0);
		}).entries(flattened)

		var totalTriads = nested.map(function(d) {
			return d.value
		}, []).reduce(function(acc, curr) {
			return acc += curr;
		}, 0)

		nested = nested.map(function(d) {
			d.totalTriads = totalTriads;
			return d;
		}, [])

		drawTriads(nested);

		if (processed >= count && !normalDistribution) {
			normalDistribution = [].concat(nested);

			g.append("path").attr('id', 'normalDistributionPath').datum(
					normalDistribution).attr("class", "normal-line").attr("d",
					function(d) {
						return line(d);
					});
		}
	}
}

var getTradeHistogramData = function() {
	selectedPage = 1;
	d3.select('#tradeHistogramDiv').selectAll("*").remove();
	$('#loading').fadeIn(200);
	d3.select("#tradeHistogramsYears").text("");

	var margin = {
		top : 0,
		right : 35,
		bottom : 0,
		left : 35
	}, width = 600 - margin.left - margin.right, height = 20 - margin.top
			- margin.bottom;

	var x = d3.scaleLinear().domain([ 0, 100 ]).range([ 0, width ]);

	var brush = d3.brushX().extent([ 0, 100 ]).on("end", brushended);

	var svg = d3.select("#tradeHistogramFooter").append("g").attr("transform",
			"translate(" + margin.left + "," + margin.top + ")");

	svg.append("rect").attr("class", "grid-background").attr("width", width)
			.attr("height", height);

	svg.append("g").attr("class", "x grid").attr("transform",
			"translate(0," + height + ")").call(
			d3.axisBottom().scale(x).ticks(10).tickSize(-height).tickFormat(
					function(d) {
						return d + "% GDP"
					})).selectAll(".tick").classed("minor", function(d) {
		return d;
	})

	var gBrush = svg.append("g").attr("class", "brush").call(brush)

	gBrush.selectAll("rect").attr("height", height);

	function brushended() {
		if (!d3.event.sourceEvent)
			return;
		percents = d3.event.target.extent().map(function(d) {
			return d / 100
		});
		updateHistograms();
	}

	$.ajax({
		url : service_url + 'dbtradehistogramcountrydata?' + 'minYear='
				+ minYear + '&' + 'maxYear=' + maxYear + '&' + 'callback=?',
		dataType : 'jsonp',
		success : function(json) {
			$('#loading').hide();
			$("#main").show();
			loadMap();
			for ( var countryIndex in countries) {
				totalExportValue = json.filter(function(d) {
					return d.ExportingCountryCode == countryIndex;
				}, []).map(function(d) {
					return +(d.TradeLinksValue);
				}).reduce(function(acc, curr) {
					return acc + curr;
				}, 0);
				totalImportValue = json.filter(function(d) {
					return d.ImportingCountryCode == countryIndex;
				}, []).map(function(d) {
					return +(d.TradeLinksValue);
				}).reduce(function(acc, curr) {
					return acc + curr;
				}, 0);
				countries[countryIndex].TotalImportValue = totalImportValue;
				countries[countryIndex].TotalExportValue = totalExportValue;
			}

			var nestedData = d3.nest().key(function(d) {
				return +(d.ItemCode);
			}).entries(json);

			nestedData = nestedData.filter(
					function(d) {
						d.values = d.values.filter(function(d) {
							return countries[d.ExportingCountryCode]
									&& countries[d.ImportingCountryCode];
						})
						return d.values.length > 1;
					}).sort(function(a, b) {
				return itemCodes[a.key] < itemCodes[b.key] ? -1 : 1
			})
			selectedItem = nestedData[0].key;
			rawData = [].concat(nestedData);
			rawJSON = json;
			d3.select("#tradeHistogramsYears").text(minYear + " to " + maxYear)
			drawAllHistograms(nestedData);
			getTriadDistribution(nestedData);
			function wait() {
				if (layers.length == 0) {
					setTimeout(wait, 100);
				} else {
					drawNetworkGraph(nestedData);
				}
			}
			wait();
			showPages();
		}
	});
}

var linkSizeThreshold = 0;
var graph = {};
var force;
var linkScale;
var color = d3.scaleOrdinal(d3.schemeCategory20);

function updateNetworkGraph(data) {
	if (!data)
		data = rawData;
	var rawLinks = [];

	for ( var good in data) {
		if (selectedItem) {
			if (data[good].key == selectedItem) {
				rawLinks = rawLinks.concat(data[good].values);
			}
		} else {
			rawLinks = rawLinks.concat(data[good].values);
		}
	}

	links = rawLinks
			.map(
					function(d) {
						d.value = {
							original : +d.TradeLinksValue,
							adjusted : (selectedCountry && d.ExportingCountryCode == ISO3toCC[selectedCountry.feature.properties.ISO3]) ? +d.TradeLinksValue
									* (1 - exportReduction)
									: +d.TradeLinksValue,
						};
						return d;
					})
			.filter(
					function(d) {
						return d.ImportingCountryCode
								&& d.ExportingCountryCode
								&& ((!selectedCountry) || (d.ExportingCountryCode == ISO3toCC[selectedCountry.feature.properties.ISO3] || d.ImportingCountryCode == ISO3toCC[selectedCountry.feature.properties.ISO3]))
								&& d.value.original >= linkSizeThreshold

					}, []);

	var uniqueImporters = links.map(function(d) {
		return d.ImportingCountryCode
	}).sort().filter(function(el, i, a) {
		if (i == a.indexOf(el))
			return 1;
		return 0
	}, []);
	if (simulate) {
		for (var index = 1; index <= layersToCascade; index++) {
			if (!selectedCountry)
				break;
			links = links.concat(rawLinks.filter(function(d) {
				return uniqueImporters.indexOf(d.ExportingCountryCode) > 0
				// && d.value.adjusted >= linkSizeThreshold
			}, []));
			uniqueImporters = links.map(function(d) {
				return d.ImportingCountryCode
			}).sort().filter(function(el, i, a) {
				if (i == a.indexOf(el))
					return 1;
				return 0
			}, []);
		}
	}

	var uniqueExporters = links.map(function(d) {
		return d.ExportingCountryCode
	}).sort().filter(function(el, i, a) {
		if (i == a.indexOf(el))
			return 1;
		return 0
	}, []);

	uniqueExporters = uniqueExporters.filter(function(d) {
		return countries[d]
	}).map(function(d, i) {
		countries[d].index = i;
		return countries[d];
	});
	uniqueImporters = uniqueImporters.filter(function(d) {
		return countries[d]
	}).map(function(d, i) {
		countries[d].index = i;
		return countries[d];
	});

	var uniqueCountries = uniqueExporters.concat(uniqueImporters).filter(
			function(el, i, a) {
				if (i == a.indexOf(el))
					return 1;
				return 0
			}, []).sort(function(a, b) {
		return (a.TotalExportValue || 0) > (b.TotalExportValue || 0) ? -1 : 1
	})

	graph.links = d3.nest().key(function(d) {
		return d.source + "," + d.target;
	}).rollup(function(d) {
		return d.reduce(function(acc, curr) {
			return {
				adjusted : acc.adjusted + curr.value.adjusted,
				original : acc.original + curr.value.original,
			};
		}, {
			adjusted : 0,
			original : 0
		})
	}).entries(links.map(function(d) {
		return {
			source : d.ExportingCountryCode,
			target : d.ImportingCountryCode,
			good : itemCodes[d.ItemCode],
			value : d.value
		}
	})).map(function(d) {
		var sourceCC = d.key.split(",")[0];
		var targetCC = d.key.split(",")[1];
		return {
			source : uniqueCountries.filter(function(d) {
				return d["Country Code"] == sourceCC;
			}, [])[0],
			target : uniqueCountries.filter(function(d) {
				return d["Country Code"] == targetCC;
			}, [])[0],
			good : selectedItem ? itemCodes[selectedItem] : "All Goods",
			value : d.value,
		}
	}).sort(function(a, b) {
		return a.value.original > b.value.original ? -1 : 1;
	})

	graph.nodes = uniqueCountries;
	graph.uniqueExporters = uniqueExporters;

	radiusScale = d3.scaleLinear().domain(
			d3.extent(graph.nodes.map(function(d) {
				return d.TotalExportValue
			}))).range([ 10, 30 ])

	graph.nodes = graph.nodes
			.map(function(d) {
				d.radius = radiusScale(d.TotalExportValue);
				d.x = layers[d["Country Code"]].feature.properties.LON * 5
						+ networkGraphWidth / 2;
				d.y = -layers[d["Country Code"]].feature.properties.LAT * 10
						+ networkGraphHeight / 2;
						d.SelectedGoodTotalExport = rawLinks
								.reduce(
										function(acc, curr) {
											if (curr.ExportingCountryCode == d["Country Code"]) {
												return acc
														+ curr.value.original;
											} else {
												return acc;
											}
										}, 0),
						d.SelectedGoodReducedValue = rawLinks
								.reduce(
										function(acc, curr) {
											if (curr.ImportingCountryCode == d["Country Code"]) {
												return acc
														+ (curr.value.original - curr.value.adjusted);
											} else {
												return acc;
											}
										}, 0),
						d.DownstreamReduction = (d.SelectedGoodTotalExport == 0 || d.SelectedGoodReducedValue > d.SelectedGoodTotalExport) ? 1
								: d.SelectedGoodReducedValue
										/ d.SelectedGoodTotalExport
				return d;
			});
	if (simulate) {
		graph.links = graph.links.map(function(d) {
			d.value.adjusted = d.value.adjusted
					* (1 - d.source.DownstreamReduction);
			return d;
		})
	}

	var linkData = networkGraphGroup.Links.selectAll('path').data(
			graph.links.filter(function(d) {
				return d.source && d.target
			}),
			function(d) {
				return d.source["Country Code"] + ","
						+ d.target["Country Code"];
			});
	linkData.exit().remove()

	linkScale = d3.scaleLinear().domain(
			[ 0, d3.max(graph.links.map(function(d) {
				return d.value.adjusted
			})) ]).range([ 3, 30 ]);
	linkData
			.transition()
			.duration(750)
			.ease(d3.easeLinear)
			.style('stroke-width', function(d) {
				return linkScale(d.value.original) + 'px'
			})
			.style(
					'stroke-dasharray',
					function(d) {
						if (d.value.adjusted == 0) {
							return [ 10, 50 ];
						}
						if (selectedCountry
								&& d.source["Country Code"] != ISO3toCC[selectedCountry.feature.properties.ISO3]) {
							return [ 10 ];
						}
					}).style("stroke", function(d) {
				return color(d.source["Country Code"]);
			})
	var linkGroup = linkData
			.enter()
			.append("path")
			.style('stroke-width', function(d) {
				return linkScale(d.value.original) + 'px'
			})
			.style(
					'stroke-dasharray',
					function(d) {
						if (d.value.adjusted == 0) {
							return [ 10, 50 ];
						}
						if (selectedCountry
								&& d.source["Country Code"] != ISO3toCC[selectedCountry.feature.properties.ISO3]) {
							return [ 10 ];
						}
					})
			.style("stroke", function(d) {
				return color(d.source["Country Code"]);
			})
			.on('mouseout', function(d) {
				tooltip.style('visibility', 'hidden')
			})
			.on('mousemove', function(d) {
				tooltip.html(linkToolTip(d))
				ttPosition();

			})
			.attr(
					"d",
					function(d) {
						var x1 = d.source.x, y1 = d.source.y, x2 = d.target.x, y2 = d.target.y;

						return d3.line().curve(d3.curveBasis)(
								[ [ x1, y1 ], [ x2, y1 ], [ x2, y2 ],
										[ x2, y2 ], [ x2, y2 ], [ x2, y2 ],
										[ x2, y1 ], [ x1, y1 ] ]);
					});

	var nodeData = networkGraphGroup.Nodes.selectAll("circle").data(
			graph.nodes.reverse(), function(d) {
				return d["Country Code"];
			})

	nodeData.exit().remove()
	nodeData.classed("inactive", false)
	nodeData.transition().duration(100).attr("r", function(d) {
		return d.radius;
	})
	nodeData.enter().append("circle").attr("r", function(d) {
		return d.radius;
	}).attr("fill", function(d) {
		return color(d["Country Code"]);
	}).on('mouseout', function(d) {
		tooltip.style('visibility', 'hidden')
	}).on(
			'mousemove',
			function(d) {
				if (d3.select(this).classed("inactive"))
					return;
				tooltip.html('<h4>' + d.Country + '</h4>').style('top',
						(d3.event.pageY + -70) + 'px')
						.style(
								'left',
								(d3.event.pageX + (d3.event.pageX
										/ self.innerWidth < 0.5 ? 25 : -1
										* (tooltip.node().clientWidth + 25)))
										+ 'px').style('visibility', 'visible')

			}).on('click', function(d) {
		updateSelectedCountry(layers[+d["Country Code"]])
	})
	updateChoropleth();
	if (!force) {
		force = d3.forceSimulation().nodes(graph.nodes).force("collide",
				d3.forceCollide(function(d) {
					return d.radius + 10;
				})).on("tick", forceTick)
	}

	getTriadDistribution(data);

	force.stop().alpha(1).restart();
}

function ttPosition() {
	tooltip.style('top', (d3.event.pageY + -70) + 'px').style(
			'left',
			(d3.event.pageX + (d3.event.pageX / self.innerWidth < 0.5 ? 25 : -1
					* (tooltip.node().clientWidth + 25)))
					+ 'px').style('visibility', 'visible')
}

var linkToolTip = function(d) {
	return '<h4>'
			+ d.source.Country
			+ ' > '
			+ d.target.Country
			+ '</h4>'
			+ '<h4>'
			+ d.good
			+ '</h4>'
			+ '<h4>$'
			+ (d.value.adjusted * 1000).toLocaleString()
			+ '</h4>'
			+ (simulate ? ('<h4>(Before: $'
					+ (d.value.original * 1000).toLocaleString() + ')</h4>')
					: '')
			+ (simulate ? ('<h4>(Delta: -$'
					+ ((d.value.original - d.value.adjusted) * 1000)
							.toLocaleString() + ')</h4>') : '');
}
var networkGraphGroup = {};
var radiusScale;
var networkGraphWidth = 1600, networkGraphHeight = 1600;

function drawNetworkGraph(data) {
	d3.select("#network-graph").selectAll('svg').remove();
	var svg = d3.select("#network-graph").append('svg');

	svg.attr("preserveAspectRatio", "xMinYMin meet").attr("viewBox",
			"0 0 " + networkGraphWidth + " " + networkGraphHeight).classed(
			"svg-content-responsive", true);

	svg.append("rect").attr("width", networkGraphWidth).attr("height",
			networkGraphHeight).style("fill", "none").style("pointer-events",
			"all").call(d3.zoom().scaleExtent([ 1, 5 ]).on("zoom", zoomed));

	var g = svg.append("g")

	function zoomed() {
		g.attr("transform", d3.event.transform);
	}

	networkGraphGroup.Links = g.append('g').attr("class", "links")
	networkGraphGroup.Nodes = g.append('g').attr("class", "nodes")
	updateNetworkGraph();

}
function forceTick() {
	d3.select('.nodes').selectAll("circle").attr(
			"cx",
			function(d) {
				if (Number.isNaN(d.x)) {
					d.x = layers[d["Country Code"]].feature.properties.LON * 5
							+ networkGraphWidth / 2;
				}
				d.x = Math.min(Math.max(d.x, 0 + radiusScale.range()[1] / 2),
						networkGraphWidth - radiusScale.range()[1])

				return d.x
			}).attr(
			"cy",
			function(d) {
				if (Number.isNaN(d.y)) {
					d.y = -layers[d["Country Code"]].feature.properties.LAT
							* 10 + networkGraphHeight / 2;
				}
				d.y = Math.min(Math.max(d.y, 0 + radiusScale.range()[1] / 2),
						networkGraphHeight - radiusScale.range()[1]);

				return d.y;
			});

	d3
			.select('.links')
			.selectAll("path")
			.attr(
					"d",
					function(d) {
						var x1 = d.source.x, y1 = d.source.y, x2 = d.target.x, y2 = d.target.y;

						return d3.line().curve(d3.curveBasis)(
								[ [ x1, y1 ], [ x2, y1 ], [ x2, y2 ],
										[ x2, y2 ], [ x2, y2 ], [ x2, y2 ],
										[ x2, y1 ], [ x1, y1 ] ]);
					});
}

function getDBTable(tableName, callback) {
	$.ajax({
		url : service_url + 'dbgettable/?tableName=' + tableName
				+ '&callback=?',
		dataType : 'jsonp',
		success : callback
	});
}

function getDBCodes() {
	// Get the countries table and store the codes in 2 lookup
	// dictionaries. One to lookup a POP code from an FAO code,
	// and one to look up an FAO code from a POP code
	getDBTable(
			'ALL_Countries',
			function(countries) {
				POPtoFAO = {};
				FAOtoPOP = {};
				for (i in countries) {
					if (countries[i]['POP_CountryCode'] != 0
							&& countries[i]['POP_CountryCode'] != 0) {
						POPtoFAO[countries[i]['POP_CountryCode']] = countries[i]['FAO_CountryCode'];
						FAOtoPOP[countries[i]['FAO_CountryCode']] = countries[i]['POP_CountryCode'];
					}
					// CHINA FIX
					POPtoFAO["156"] = "41";
					FAOtoPOP["41"] = "156";
					// SUDAN FIX
					POPtoFAO["736"] = "206";
					FAOtoPOP["206"] = "736";
					// Switzerland FIX
					POPtoFAO["744"] = "211";
					FAOtoPOP["211"] = "744";
				}
			});

	// Get all of the items in DB, storing each one in a lookup
	// dictionary by code. Also populate the item dropdown on
	// the page
	getDBTable('FAO_Items', function(items) {
		items.sort(function(a, b) {
			if (a.Item < b.Item) {
				return -1;
			} else if (a.Item > b.Item) {
				return 1;
			} else {
				return 0;
			}
		});
		itemCodes = {};
		for (i in items) {
			itemCodes[items[i]['ItemCode']] = items[i]['Item'];
		}
	});
}

var drawAllHistograms = function(data) {
	if (!data) {
		data = [].concat(rawData);
	}

	d3.select('#tradeHistogramDiv').selectAll("*").remove()

	filteredData = data.filter(function(d) {
		return d.values.length >= selectedLinkSizeThreshold
	})

	var paginatedData = filteredData.filter(function(d, i) {
		return i >= ((selectedPage - 1) * pageSize)
				&& i < (selectedPage * pageSize);
	});

	var graphs = d3.select('#tradeHistogramDiv').selectAll('.thumbnail').data(
			paginatedData).enter().append('div').classed("thumbnail", true)
			.classed("col-sm-12", true).classed("inactive", function(d) {
				return selectedItem && (+d.key != +selectedItem)
			}).attr('id', function(d) {
				return "div_" + d.key;
			}).append('div').classed('svg-container-ws', true).append('svg')
			.attr('class', 'thumbnailCanvas')

	if (paginatedData.length == 0) {
		d3.select('#tradeHistogramDiv').append('h2').text(
				'No Data. Please refine filters.').on('click', function(d) {
			selectedPage = 1;
			selectedItem = null;
			updateHistograms();
		})
	}

	d3.selectAll('.thumbnailCanvas').on('click', function(d) {
		if (!selectedItem || selectedItem != d.key) {
			selectedItem = d.key;
			d3.selectAll(".thumbnail").classed("inactive", function(d) {
				return selectedItem && +d.key != +selectedItem
			})
			updateNetworkGraph();
		}
	}).each(function(d) {
		drawHistogram(this, d);
	});
	d3.selectAll('.filterButton').style('display', null);
	d3.selectAll('#loadingIcon').style('display', 'none');
	d3.select("#executeButton").style('display', null);
	showPages();
}

var drawHistogram = function(svg, nestedData) {

	var item = itemCodes[nestedData.key], data = nestedData.values;

	var width = 160, height = 90;

	var margin = {
		top : 15,
		right : 15,
		bottom : 15,
		left : 15
	}, chartWidth = width - margin.left - margin.right, chartHeight = height
			- margin.top - margin.bottom;

	var svg = d3.select(svg);

	svg.attr("preserveAspectRatio", "xMinYMin meet").attr("viewBox",
			"0 0 " + width + " " + height).classed("svg-content-responsive",
			true);

	svg.selectAll("*").remove()
	svg.append("text").attr('id', 'itemHeader_' + nestedData.key).attr(
			'data-toggle', 'tooltip').attr('data-placement', 'top').attr(
			'title', item).attr("y", margin.top / 2).attr("x", 5).attr(
			"text-anchor", "left").text(nestedData.key + ": " + item);

	$('[data-toggle="tooltip"]').tooltip();

	var g = svg.append('g').attr('transform',
			"translate(" + margin.left + "," + margin.top + ")");

	var x = d3.scaleLinear() // v3
	.domain(d3.range(0, numberofBins, 1)).rangeRound([ 0, chartWidth ]).nice();

	// var bins = d3.histogram()
	var bins = d3
			.histogram()
			.domain(x.domain())
			// v4
			.value(
					function(d) {
						if (selectedType.Unit == "%") {
							return countries[d.ExportingCountryCode] ? +(d.TradeLinksValue)
									/ countries[d.ExportingCountryCode].TotalExportValue
									: 0;
						} else if (selectedType.Unit.lastIndexOf('SQRT', 0) == 0) {
							return Math.sqrt(+(d.TradeLinksValue));
						}
						return +(d.TradeLinksValue);
					})(data);

	bins = bins.map(function(d) {
		d.sort(function(a, b) {
			return +(a.TradeLinksValue) > +(b.TradeLinksValue) ? -1 : 1;
		})
		return d;
	})
	var oneBin = (bins.filter(function(d) {
		return d.length > 0;
	}).length == 1)

	var y = d3.scaleLinear() // v3
	.domain([ 0, d3.max(bins, function(d) {
		return d.length;
	}) ]).range([ chartHeight, 0 ]);

	var bar = g.selectAll(".bar").data(bins).enter().append("g").attr("class",
			"bar").attr("transform", function(d) {
		return "translate(" + x(d.x0) + "," + y(d.length) + ")"; // v4
	})

	g
			.selectAll(".tooltipPlaceholder")
			.data(bins)
			.enter()
			.append("g")
			.attr("class", "tooltipPlaceholder")
			.attr("transform", function(d) {
				return "translate(" + x(d.x0) + ",0" + ")"; // v4
			})
			.append('rect')
			.style('fill', 'transparent')
			.attr("x", 1)
			.attr('height', function(d) {
				return chartHeight;
			})
			.attr("width", x(bins[0].x1) - x(bins[0].x0) - 1)
			// v4
			.on('mousemove', ttPosition)
			.on(
					'mouseover',
					function(d) {
						var countriesIncluded = "";
						for (var index = 0; index < 5; index++) {
							if (d[index]) {
								countriesIncluded += '<h5>'
										+ countries[d[index].ExportingCountryCode].Country
										+ ' to '
										+ (countries[d[index].ImportingCountryCode] ? countries[d[index].ImportingCountryCode].Country
												: d[index].ImportingCountryCode)
										+ ' ('
										+ (selectedType.Unit == '%' ? (d[index].TradeLinksValue
												/ countries[d[index].ExportingCountryCode].TotalExportValue * 100)
												.toFixed(2)
												+ '%'
												: siFormat(d[index].TradeLinksValue))
										+ ')</h5>';
							}
						}
						tooltip
								.style('visibility', 'visible')
								.html(
										'<h4>'
												+ item
												+ '</h5>'
												+ '<h5>'
												+ d.length
												+ ' trade links between '
												+ (selectedType.Unit == '%' ? (d.x0 * 100)
														.toFixed(4)
														: siFormat(d.x0))
												+ ' and '
												+ (selectedType.Unit == '%' ? (d.x1 * 100)
														.toFixed(4)
														: siFormat(d.x1))
												+ ' '
												+ selectedType.Unit
												+ ' of Exporting Country GDP</h5>'
												+ countriesIncluded);
					}).on('mouseout', function(d) {
				tooltip.style('visibility', 'hidden')
			})

	bar.append("rect").attr("x", 1).attr('fill', 'steelblue').attr("width",
			oneBin ? chartWidth - 2 : ((chartWidth - 2) / numberofBins - 2))
	// .attr("width", x(bins[0].dx) <= 0 ? chartWidth : x(bins[0].dx)) // v3
	// .attr("width", x(bins[0].x1) - x(bins[0].x0) - 2) // v4
	.attr("height", function(d) {
		return chartHeight - y(d.length);
	})
}

var showPages = function() {
	if (numberOfPages() > 0) {
		d3.select("#selectedPageSelect").style('display', null)
		d3.select("#selectedPageSelect").selectAll("*").remove();
		d3.select("#selectedPageSelect").selectAll('option').data(
				d3.range(1, numberOfPages() + 1, 1)).enter().append('option')
				.text(function(d) {
					return "Page " + d + " of " + numberOfPages();
				}).attr('value', function(d) {
					return d;
				}).attr('id', function(d) {
					return 'page_' + d;
				}).attr('class', 'trade_type').attr('selected', function(d) {
					return d == selectedPage ? 'selected' : null;
				}).style('color', 'black').style('height', '20px').style(
						'position', 'absolute').style('top', function(d, i) {
					return (i * 20) + 'px';
				})
	}
}

var tooltip = d3.select('body').append('div').attr('class', 'tooltip').style(
		'position', 'absolute').style('z-index', '10').style('visibility',
		'hidden')
var mapBounds = [ [ -69.761568, -169.179395 ], [ 83.933328, 192.228819 ] ];
function loadBaseMap(mapName) {
	var map = L.map(mapName, {
		center : [ 35, 10 ],
		zoom : 2,
		zoomSnap : 0.001,
		zoomDelta : 0.001,
		// minZoom: 1.7,
		maxBounds : mapBounds,
		attributionControl : false,
		zoomControl : false,
	});
	map.fitBounds(mapBounds);
	map.once('zoomend', function() {
		map.setMinZoom(map.getZoom());
	});
	L.tileLayer(
			'https://api.mapbox.com/styles/v1/' + MBSTYLE
					+ '/tiles/256/{z}/{x}/{y}?access_token=' + MBTOKEN).addTo(
			map);
	return map;
}

var map;
function onEachFeature(feature, layer) {
	layers[ISO3toCC[layer.feature.properties.ISO3]] = layer;
	layer
			.on({
				click : selectCountry,
				mousemove : function(e) {
					var countryIndex = ISO3toCC[layer.feature.properties.ISO3];
					if (countryIndex) {
						var imports = countries[countryIndex].TotalImportValue
								.toLocaleString();
						var exports = countries[countryIndex].TotalExportValue
								.toLocaleString();
					}
					tooltip
							.style('top', ((e.originalEvent.pageY - 70) + 'px'))
							.style('left',
									((e.originalEvent.pageX + 25) + 'px'))
							.style('visibility', 'visible')
							.html(
									'<H2>'
											+ e.target.feature.properties.NAME
											+ "</h3>"
											+ "<h4>"
											+ (e.target.feature.affectedPercent ? ("Percentage of "
													+ itemCodes[selectedItem]
													+ " imports affected (including cascaded): "
													+ (e.target.feature.affectedPercent * 100)
															.toFixed(4) + "%")
													: "")
											+ "</h4>"
											+ "<h4>Total Imports: "
											+ (imports ? ("$"
													+ imports.toLocaleString() + ",000")
													: "Unknown")
											+ "</h4>"
											+ "<h4>Total Exports: "
											+ (exports ? ("$"
													+ exports.toLocaleString() + ",000")
													: "Unknown") + "</h4>")
				},
				mouseout : function(e) {
					tooltip.style('visibility', 'hidden');
				},
			});
}

var selectedCountry;

// Called when a user clicks (selects) a country
function selectCountry(e) {
	if (rawData) {
		var continueProcess = updateSelectedCountry(e.target);
		if (continueProcess) {
			$('#singularity-dialog').modal('show');
		}
	}
}

var updateGUISelectedCountry = function() {
	d3.selectAll(".country-path").classed('active', false);
	if (selectedCountry) {
		d3.select(selectedCountry._path).classed('active', true);
		networkGraphGroup.Nodes
				.selectAll('circle')
				.classed(
						'focus',
						function(d) {
							return d["Country Code"] == ISO3toCC[selectedCountry.feature.properties.ISO3]
						});
	} else {
		networkGraphGroup.Nodes.selectAll('circle').classed('focus', false);
	}
	return;
	graph.node = d3.select('.nodes').selectAll("circle");
	graph.link = d3.select('.links').selectAll("path");

	graph.node.classed('focus', false);
	graph.node.classed('active', true);
	graph.node.classed('inactive', false);
	graph.link.classed('active', true)
	graph.link.classed('inactive', false);
	if (selectedCountry) {
		graph.link.classed('active', false);
		var selectedCountryGraphIndex = graph.nodes
				.filter(
						function(d) {
							return d["Country Code"] == ISO3toCC[selectedCountry.feature.properties.ISO3];
						}, []).map(function(d) {
					return d.index;
				})[0];
		d3.selectAll('.focus').each(function(d) {
			currentlySelected = d.index;
		})
		d3.select(selectedCountry._path).classed('active', true);
		d3.selectAll('.focus').classed('focus', false);
		graph.node.classed('active', function(d) {
			return selectedCountryGraphIndex == d.index;
		});
		graph.node.classed('inactive', true)
		graph.link.classed('inactive', function(d) {
			return false;
			var sourceIndex = d.source.index;
			var targetIndex = d.target.index;
			if (graph.uniqueExporters.indexOf(d.source["Country Code"]) > 0
					|| targetIndex == selectedCountryGraphIndex) {
				graph.node.classed('active', function(d) {
					if (d.index == sourceIndex || d.index == targetIndex) {
						return true;
					} else {
						return d3.select(this).classed('active')
					}
				})
				return false;
			} else {
				return true;
			}
		})

		d3.selectAll('.active').classed('inactive', false);
	}
	return true;
}

var updateSelectedCountry = function(countryLayer) {
	if (!selectedCountry || selectedCountry != countryLayer) {
		selectedCountry = countryLayer
	} else {
		selectedCountry = null
	}
	updateGUISelectedCountry();
	updateNetworkGraph();
}

var calculateAffectedValues = function(layer, exporter, reduction, iteration) {
	if (iteration > layersToCascade)
		return;
	if (!selectedCountry) {
		layer.feature.affectedValue = 0;
		return;
	}
	var importingCountryIndex = ISO3toCC[layer.feature.properties.ISO3];
	var exportingCountryIndex = exporter
			|| ISO3toCC[selectedCountry.feature.properties.ISO3];
	layer.feature.affectedValue += getAffectedValue(exportingCountryIndex,
			importingCountryIndex, reduction || exportReduction, selectedItem,
			iteration || 0);
}

var choropleth = function(layer) {
	var color = d3.interpolateRgb('yellow', 'red');
	var importingCountryIndex = ISO3toCC[layer.feature.properties.ISO3];
	var affectedPercent = +((layer.feature.affectedValue || 0) / rawJSON
			.filter(
					function(d) {
						return (!selectedItem || selectedItem == d.ItemCode)
								&& d.ImportingCountryCode == importingCountryIndex;
					}, []).map(function(d) {
				return +(d.TradeLinksValue);
			}, 0).reduce(function(acc, curr) {
				return acc + curr;
			}, 1));
	layer.setStyle({
		"fillColor" : color(affectedPercent * 10),
		"fillOpacity" : affectedPercent <= 0.01 ? 0 : affectedPercent * 3
	});
	layer.feature.affectedPercent = affectedPercent;
}

var exportReductionThreshold = 0.1;
var getAffectedValue = function(exporter, importer, reduction, itemCode,
		iteration) {
	if (importer == "33") {
		stope = 1;
	}
	if (importer && countries[importer] && exporter && countries[exporter]) {
		var affectedValue = rawJSON.filter(
				function(d) {
					return (!itemCode || itemCode == d.ItemCode)
							&& d.ImportingCountryCode == importer
							&& d.ExportingCountryCode == exporter;
				}, []).map(function(d) {
			return +(d.TradeLinksValue) * reduction;
		}, 0).reduce(function(acc, curr) {
			return acc + curr;
		}, 0)

		var totalImports = rawJSON.filter(
				function(d) {
					return (!itemCode || itemCode == d.ItemCode)
							&& d.ImportingCountryCode == importer;
				}, []).map(function(d) {
			return +(d.TradeLinksValue);
		}, 0).reduce(function(acc, curr) {
			return acc + curr;
		}, 0)

		if (totalImports > 0
				&& (affectedValue / totalImports >= exportReductionThreshold)) {
			shpFile.layer.eachLayer(function(layer) {
				calculateAffectedValues(layer, importer, affectedValue
						/ totalImports, iteration + 1)
			});
		}
	}
	return affectedValue;
}

var shpFile;
var exportReduction = 0;
var layers = [];

function loadShpFile(url, map, onEach) {
	var result = {};
	shp(url).then(function(geojson) {
		result.layer = L.geoJson(geojson, {
			style : {
				weight : 0,
				color : "transparent",
				className : "country-path"
			},
			class : "country",
			onEachFeature : onEach
		}).addTo(map);
		result.geojson = geojson;
	});
	return result;
}

function initSliders() {
	var width = 500;
	var height = 25;
	var pad = width / 10;

	var margin = {
		'left' : 0,
		'right' : 0,
		'bottom' : 0,
		'top' : 0
	};
	var svg = d3.select('#export-reduction-slider-ticks').classed(
			"svg-container-ticks", true).append('svg').style('overflow',
			'visible').attr("viewBox", "0 0 " + width + " " + height).classed(
			"svg-content-responsive", true);

	var g = svg.append('g').attr('transform', function() {
		return 'translate(' + [ margin.left, margin.top ] + ')';
	});

	var g_enter = g.selectAll('.export-reduction-slider-ticks-g').data(
			d3.range(0, 55, 5)).enter().append('g').attr('class',
			'export-reduction-slider-ticks-g');

	g_enter.append('line').attr('x1', function(d, i) {
		return i * pad;
	}).attr('x2', function(d, i) {
		return i * pad;
	}).attr('y1', 0).attr('y2', 8).style('stroke', 'black').style(
			'stroke-width', '1px');

	g_enter.append('text').attr('y', 10).attr('x', function(d, i) {
		return i * pad;
	}).attr('text-anchor', 'middle').attr('dominant-baseline', 'hanging').attr(
			'font-size', '2em').text(function(d) {
		return d + '%';
	});

	$("#export-reduction-slider").slider({
		value : 0,
		range : false,
		min : 0,
		max : 50,
		step : 5,
		stop : function(event, ui) {
			exportReduction = ui.value / 100;
			updateNetworkGraph();
		}
	});

	var downstreamRange = [ 0, 3 ];
	var downstreamPad = width / (downstreamRange[1] - downstreamRange[0]);

	var svg_downstream = d3.select('#downstream-export-reduction-slider-ticks')
			.classed("svg-container-ticks", true).append('svg').style(
					'overflow', 'visible').attr("viewBox",
					"0 0 " + width + " " + height).classed(
					"svg-content-responsive", true);

	var g_downstream = svg_downstream.append('g').attr('transform', function() {
		return 'translate(' + [ margin.left, margin.top ] + ')';
	});

	var g_enter_downstream = g_downstream.selectAll(
			'.downstream-export-reduction-slider-ticks-g').data(
			d3.range(downstreamRange[0], downstreamRange[1] + 1, 1)).enter()
			.append('g').attr('class',
					'downstream-export-reduction-slider-ticks-g');

	g_enter_downstream.append('line').attr('x1', function(d, i) {
		return i * downstreamPad;
	}).attr('x2', function(d, i) {
		return i * downstreamPad;
	}).attr('y1', 0).attr('y2', 8).style('stroke', 'black').style(
			'stroke-width', '1px');

	g_enter_downstream.append('text').attr('y', 10).attr('x', function(d, i) {
		return i * downstreamPad;
	}).attr('text-anchor', 'middle').attr('dominant-baseline', 'hanging').attr(
			'font-size', '2em').text(function(d) {
		return d;
	});

	$("#downstream-export-reduction-slider").slider({
		value : 1,
		range : false,
		min : downstreamRange[0],
		max : downstreamRange[1],
		step : 1,
		stop : function(event, ui) {
			layersToCascade = ui.value;
			updateNetworkGraph();
		}
	});

	var linkSizeThresholdRange = [ 0, 1000000 ];
	var numberLinkSizeThresholdTicks = 10;
	var linkSizeThreshold_width = 500, linkSizeThreshold_height = 25;
	var linkSizeThresholdPad = linkSizeThreshold_width
			/ numberLinkSizeThresholdTicks;

	var svg_linkSizeThreshold = d3.select('#linkSizeThreshold-slider-ticks')
			.classed("svg-container-ticks", true).append('svg').style(
					'overflow', 'visible').attr(
					"viewBox",
					"0 0 " + linkSizeThreshold_width + " "
							+ linkSizeThreshold_height).classed(
					"svg-content-responsive", true);

	var g_linkSizeThreshold = svg_linkSizeThreshold.append('g');

	var g_enter_linkSizeThreshold = g_linkSizeThreshold.selectAll(
			'.linkSizeThreshold-slider-ticks-g').data(
			d3.range(linkSizeThresholdRange[0], linkSizeThresholdRange[1] + 1,
					(linkSizeThresholdRange[1] - linkSizeThresholdRange[0])
							/ numberLinkSizeThresholdTicks)).enter()
			.append('g').attr('class', 'linkSizeThreshold-slider-ticks-g');

	g_enter_linkSizeThreshold.append('line').attr('x1', function(d, i) {
		return i * linkSizeThresholdPad;
	}).attr('x2', function(d, i) {
		return i * linkSizeThresholdPad;
	}).attr('y1', 0).attr('y2', 8).style('stroke', 'black').style(
			'stroke-width', '1px');

	g_enter_linkSizeThreshold.append('text').attr('y', 10).attr('x',
			function(d, i) {
				return i * linkSizeThresholdPad;
			}).attr('text-anchor', 'middle').attr('dominant-baseline',
			'hanging').attr('font-size', 8).text(function(d) {
		return siFormat(d * 1000);
	});

	$("#linkSizeThreshold-slider").slider(
			{
				value : linkSizeThresholdRange[0],
				range : false,
				min : linkSizeThresholdRange[0],
				max : linkSizeThresholdRange[1],
				step : (linkSizeThresholdRange[1] - linkSizeThresholdRange[0])
						/ numberLinkSizeThresholdTicks,
				stop : function(event, ui) {
					linkSizeThreshold = ui.value;
					updateNetworkGraph();
				}
			});
}

var updateChoropleth = function() {
	d3.select("#loading").style('display', 'block')
	d3.select("#main").classed('inactive', true)
	shpFile.layer.eachLayer(function(layer) {
		layer.feature.affectedValue = 0;
	});
	shpFile.layer.eachLayer(calculateAffectedValues);
	shpFile.layer.eachLayer(choropleth)
	d3.select("#main").classed('inactive', false)
	d3.select("#loading").style('display', 'none')
}

var loadMap = function() {
	map = loadBaseMap('map');
	// loadShpFile loads the local shp file and the geojson
	shpFile = loadShpFile("./data/worldTest", map, onEachFeature);
}

window.onload = function() {
	initSliders();
	d3.select("#checkboxSimulate").on(
			'change',
			function(d) {
				simulate = d3.select(this).property('checked');
				d3.select("#simulationDiv").style('display',
						simulate ? 'block' : 'none')
			})
	var svg = d3.select('#export-reduction-slider-ticks').append('svg').attr(
			'width', 100).attr('height', 10);

	var g = svg.append('g').attr('transform', function() {
		return 'translate(0,0)';
	});

	var g_enter = g.selectAll('.export-reduction-slider-ticks-g').data(
			d3.range(1, -0.1, -0.1)).enter().append('g').attr('class',
			'export-reduction-slider-ticks-g');

	$('#singularity-dialog').on('hidden.bs.modal', function() {
		updateChoropleth();
	})

	d3.range(1, 14, 1).forEach(
			function(d) {
				make_mortif_figure(d3.select("#triadDistributionDisplay"), d,
						true).style('background-color', 'white').attr('id',
						'triad_' + d).attr('width', (70) + 'px').attr('height',
						'90px').select('g').attr('transform',
						'translate (15,7.5)').append('text').attr('y', "60px")
						.style('text-anchor', 'center').style('font-size',
								'1.5em').text("Type " + d);
			})

	d3.csv('data/FAOSTAT_data_countrycodes.csv', function(data) {
		countries = {};
		ISO3toCC = {};
		for (var index = 0; index < data.length; index++) {
			countries[data[index]['Country Code']] = data[index];
			ISO3toCC[data[index]['ISO3 Code']] = data[index]['Country Code'];
		}
		var typeData = [];

		typeData.push({
			Element : "% Export Value",
			ElementCode : 5922,
			Unit : "%",
			Process : function(d) {
				return d;
			}
		})

		typeData.push({
			Element : "Export Value",
			ElementCode : 5922,
			Unit : "1000 US$",
			Process : function(d) {
				return d;
			}
		})

		typeData.push({
			Element : "SQRT Export Value",
			ElementCode : 5922,
			Unit : "SQRT 1000 US$",
			Process : function(d) {
				return d;
			}
		})

		typeDiv = d3.select('#options').attr('class', 'form-inline').append(
				'select').attr('id', 'itemSelect').attr('class',
				'form-control pull-left').on('change', function(d) {
			selectedType = typeData[this.selectedIndex];
			updateHistograms();
		})

		typeDiv.selectAll('option').data(typeData).enter().append('option')
				.text(function(d) {
					return d.Element;
				}).attr('id', function(d) {
					return 'type_' + d.ElementCode;
				}).attr('class', 'trade_type').style('color', 'black').style(
						'height', '20px').style('position', 'absolute').style(
						'top', function(d, i) {
							return (i * 20) + 'px';
						})

		selectedType = typeData[0];

		d3.selectAll('#loadingIcon').style('display', 'none');

		numberOfBinsDiv = d3.select('#options').attr('class', 'form-inline')
				.append('select').attr('id', 'numberOfBinsSelect').attr(
						'class', 'form-control pull-right').on('change',
						function(d) {
							numberofBins = +(this.value);
							if (rawData) {
								updateHistograms();
							}
						})

		numberOfBinsDiv.selectAll('option').data(d3.range(5, 14, 1)).enter()
				.append('option').text(function(d) {
					return d + " bins";
				}).attr('value', function(d) {
					return +(d);
				}).attr('id', function(d) {
					return 'bins_' + d;
				}).attr('selected', function(d) {
					return d == numberofBins ? 'selected' : null;
				}).style('color', 'black').style('height', '20px').style(
						'position', 'absolute').style('top', function(d, i) {
					return (i * 20) + 'px';
				})

		selectedPageDiv = d3.select('#options').attr('class', 'form-inline')
				.append('select').attr('id', 'selectedPageSelect').attr(
						'class', 'form-control pull-right').on('change',
						function(d) {
							selectedPage = +(this.value);
							if (rawData) {
								updateHistograms();
							}
						})

		d3.select('#options').append('svg').attr('id', 'tradeHistogramFooter')
				.attr('height', 30).attr('width', 600)
		getDBCodes();
		function wait() {
			if (!itemCodes || !FAOtoPOP) {
				setTimeout(wait, 100);
			} else {
				getTradeHistogramData();
			}
		}
		wait();
	});
}
